<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="<?= base_url() ?>assets/ckeditor/ckeditor.js"></script>
	<script src="<?= base_url() ?>assets/ckeditor/samples/js/sample.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 450px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      padding-top: 20px;
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height:auto;} 
    }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="<?= base_url('admin') ?>">Product list</a></li>
        <li><a href="<?= base_url('admin/add_product') ?>">Product Add</a></li>
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center" style="margin-bottom:30px">
  <div class="row content">
    <div class="col-sm-12 text-left"> 
      <h1>Welcome</h1>
      <form action="<?= base_url('admin/store_product') ?>" method="post" enctype="multipart/form-data">
		<div class="form-group row">
			<div class="col-sm-6">
			  <label for="title">Title:</label>
			  <input type="text" class="form-control" id="title" placeholder="Enter Title" name="title">
			</div>
			<div class="col-sm-6">
			  <label for="model">Model:</label>
			  <input type="text" class="form-control" id="model" placeholder="Enter Model" name="model">
			</div>
		</div>
		<div class="form-group">
		  <label for="short_des">Short Description:</label>
		  <input type="text" class="form-control" id="short_des" placeholder="Short Description" name="short_des">
		</div>
		<div class="form-group">
		  <label for="editor">Description:</label>
		  <textarea class="form-control" id="editor" name="description"></textarea>
		</div>
		<div class="form-group row">
			<div class="col-sm-4">
			  <label for="type">Type:</label>
			  <select class="form-control" id="type" name="type">
				<option value="1">Car</option>
				<option value="2">Motorcycle</option>
			  </select>
			</div>
			<div class="col-sm-4">
			  <label for="price">Price:</label>
			  <input type="text" class="form-control" id="price" placeholder="Enter Price" name="price">
			</div>
			<div class="col-sm-4">
			  <label for="image">Image:</label>
			  <input type="file" class="form-control" id="image" name="image">
			</div>
		</div>
		
		<button type="submit" class="btn btn-primary">Submit</button>
	  </form>
	</div>
  </div>
</div>

<footer class="container-fluid text-center">
  <p>Footer Text</p>
</footer>

<script>
	initSample();
</script>

</body>
</html>