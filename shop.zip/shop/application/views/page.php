
<div id="mainBody">
	<div class="container">
		<div class="row">
		<div class="span12">		
			<h4> Products </h4>
			  <ul class="thumbnails">
			  <?php if($product){
					foreach($product as $pro){ ?>
				<li class="span3">
				  <div class="thumbnail">
					<a href="<?= base_url('home/product_details/'.$pro['id'])?>"><img src="<?php echo base_url() ?>assets/images/<?= $pro['image'] ?>" alt=""/></a>
					<div class="caption">
					  <h5><?= $pro['title'] ?></h5>
					  <p> 
						<?= $pro['short_des'] ?> 
					  </p>
					 
					  <h4 style="text-align:center">
						<a class="btn" href="<?= base_url('home/product_details/'.$pro['id'])?>"> 	View
						</a>
						<a class="btn btn-primary" href="#">BDT <?= $pro['price'] ?></a>
						</h4>
					</div>
				  </div>
				</li>
			  <?php } } ?>
			</ul>	

			</div>
			
			
			
		</div>
	</div>
</div>