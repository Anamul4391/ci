
<div id="mainBody">
	<div class="container">
		<div class="row">
<div class="span12">
    <ul class="breadcrumb">
    <li><a href="index.html">Home</a> <span class="divider">/</span></li>
    <li><a href="<?= base_url('home') ?>">Products</a> <span class="divider">/</span></li>
    <li class="active">product Details</li>
    </ul>	
	<div class="row">	  
			<div id="gallery" class="span3">
				<a href="<?php echo base_url() ?>assets/images/<?= $product[0]['image'] ?>" title="<?= $product[0]['title'] ?>">
					<img src="<?php echo base_url() ?>assets/images/<?= $product[0]['image'] ?>" style="width:100%" alt="<?= $product[0]['title'] ?>"/>
				</a>
			</div>
			<div class="span9">
				<h3><?= $product[0]['title'] ?></h3>
				<small><?= $product[0]['short_des'] ?></small>
				<hr class="soft"/>
				<form class="form-horizontal qtyFrm">
				  <div class="control-group">
					<label class="control-label"><span>BDT<?= $product[0]['price'] ?></span></label>
					
				  </div>
				</form>
				
				<hr class="soft"/>
				<p>
				<?= $product[0]['short_des'] ?>
				</p>
				<a class="btn btn-small pull-right" href="#detail">More Details</a>
				<br class="clr"/>
			<a href="#" name="detail"></a>
			<hr class="soft"/>
			</div>
			
			<div class="span9">
            <ul id="productDetail" class="nav nav-tabs">
              <li class="active"><a href="#home" data-toggle="tab">Product Details</a></li>
            </ul>
            <div id="myTabContent" class="tab-content">
              <div class="tab-pane fade active in" id="home">
				<h4>Product Information</h4>
					<?= $product[0]['description'] ?>
              </div>
		</div>
          </div>

	</div>
</div>

		</div>
	</div>
</div>