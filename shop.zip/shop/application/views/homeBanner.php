<div class="item">
	<div class="container">
		<div id="carouselBlk">
			<div id="myCarousel" class="carousel slide">
				<div class="carousel-inner">
					<div class="item active">
					  <div class="container">
						<a href="<?php echo base_url('register')?>"><img style="width:100%" src="<?php echo base_url() ?>assets/themes/images/carousel/1.png" alt="special offers"/></a>
					  </div>
					</div>
				</div>
			</div>
		</div>
	</div> 
</div>
