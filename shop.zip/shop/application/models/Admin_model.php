<?php
class Admin_model extends CI_Model{

	public function getProduct($data=false){
		$this->db->select('*');
		if($data)
		$this->db->where($data);
	
		$q=$this->db->get('product');
		return $q->result_array();
	}
}