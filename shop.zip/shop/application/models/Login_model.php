<?php
class Login_model extends CI_Model{

	public function login($data){
		$this->db->select('*');
		$this->db->where($data);
		$q=$this->db->get('users');
		return $q->result_array();
	}
}