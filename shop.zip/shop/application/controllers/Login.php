<?php
class Login extends CI_Controller{

	public function login_f(){
		$this->load->model('login_model');
		$data=[
			'email'=>$this->input->post('email'),
			'password'=>$this->input->post('password')
		];
		$rs=$this->login_model->login($data);
		
		$this->session->set_userdata('login',$rs);
		redirect('admin');
	}
}
?>