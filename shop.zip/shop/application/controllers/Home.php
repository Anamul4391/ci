<?php
class Home extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('admin_model');
	}
	public function index(){
		$data['product']=$this->admin_model->getProduct();
		$this->load->helper('url');
		$this->load->view('common/header');
		$this->load->view('homeBanner.php');
		$this->load->view('home',$data);
		$this->load->view('common/footer');
	}
	public function product_details($id){
		$con['id']=$id;
		$data['product']=$this->admin_model->getProduct($con);
		$this->load->helper('url');
		$this->load->view('common/header');
		$this->load->view('product_details',$data);
		$this->load->view('common/footer');
	}
	public function page($type){
		$con['type']=$type;
		$data['product']=$this->admin_model->getProduct($con);
		$this->load->helper('url');
		$this->load->view('common/header');
		$this->load->view('page',$data);
		$this->load->view('common/footer');
	}
}
?>