<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('admin_model');
	}
	public function index(){
		$data['product']=$this->admin_model->getProduct();
		$this->load->view('admin',$data);
	}
	public function add_product(){
		$this->load->view('product_add');
	}
	
	public function store_product(){
		$image="";
		if($_FILES AND $_FILES['image']['name']){
			$image=time();
			
			$c['upload_path']="assets/images";
			$c['allowed_types']="*";
			$c['file_name']=$image;
			
			$this->load->library('upload',$c);
			if(!$this->upload->do_upload('image')){
				echo $this->upload->display_errors();
			}else{
				$sinfo= $this->upload->data();
				$image= $sinfo['file_name'];
			}
		}
		$data=[
			'title'=>$this->input->post('title'),
			'model'=>$this->input->post('model'),
			'short_des'=>$this->input->post('short_des'),
			'description'=>$this->input->post('description'),
			'type'=>$this->input->post('type'),
			'price'=>$this->input->post('price'),
			'image'=>$image,
			'created_at'=>date('Y-m-d H:i:s')
		];
		$this->db->insert('product',$data);
		$this->session->set_flashdata('msg',"data saved");
		redirect('admin');
	}
	
	
	public function edit($id){
		$con['id']=$id;
		$data['product']=$this->admin_model->getProduct($con);
		$this->load->view('product_edit',$data);
	}
	
	
	
	public function update_product($id){
		$image=$this->input->post('old_img');
		if($_FILES AND $_FILES['image']['name']){
			$image=time();
			
			$c['upload_path']="assets/images";
			$c['allowed_types']="*";
			$c['file_name']=$image;
			
			$this->load->library('upload',$c);
			if(!$this->upload->do_upload('image')){
				echo $this->upload->display_errors();
			}else{
				$sinfo= $this->upload->data();
				$image=$sinfo['file_name'];
			}
		}
		$data=[
			'title'=>$this->input->post('title'),
			'model'=>$this->input->post('model'),
			'short_des'=>$this->input->post('short_des'),
			'description'=>$this->input->post('description'),
			'type'=>$this->input->post('type'),
			'price'=>$this->input->post('price'),
			'image'=>$image,
			'created_at'=>date('Y-m-d H:i:s')
		];
		
		$this->db->where('id',$id);
		$this->db->update('product',$data);
		$this->session->set_flashdata('msg',"data updated");
		redirect('admin');
	}
	
	public function delete_pro($id){
		$con['id']=$id;
		$this->db->delete('product',$con);
		$this->session->set_flashdata('msg',"data deleted");
		redirect('admin');
	}
	
}
